export * from './ProfileNoticeboardDetail';
