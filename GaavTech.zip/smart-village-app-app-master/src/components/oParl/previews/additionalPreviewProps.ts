export type AdditionalPreviewProps = {
  withAgendaItem?: boolean;
  withPerson?: boolean;
};
