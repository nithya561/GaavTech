export const fontConfig = {
  bold: require('../../assets/fonts/OpenSans-SemiBold.ttf'),
  'bold-italic': require('../../assets/fonts/OpenSans-SemiBoldItalic.ttf'),
  regular: require('../../assets/fonts/OpenSans-Regular.ttf'),
  italic: require('../../assets/fonts/OpenSans-Italic.ttf'),
  condbold: require('../../assets/fonts/OpenSans_Condensed-Bold.ttf'),
  'condbold-italic': require('../../assets/fonts/OpenSans_Condensed-BoldItalic.ttf'),
  'condbold-regular': require('../../assets/fonts/OpenSans_Condensed-Regular.ttf')
};
