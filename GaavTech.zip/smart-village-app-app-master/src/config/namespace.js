import appJson from '../../app.json';

export const namespace = appJson.expo.slug;
