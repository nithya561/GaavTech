export const DOWNLOAD_TYPE = {
  DOWNLOADABLE: 'downloadable',
  DOWNLOADED: 'downloaded',
  DOWNLOADING: 'downloading'
};
