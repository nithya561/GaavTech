## Changes proposed in this PR:

Please explain your changes in addition to your commit messages.

---

**Add issue number, if available:**

Fixes #

---

## How to test:
* [ ] Android portrait mode
* [ ] iOS portrait mode
* [ ] Android landscape mode
* [ ] iOS landscape mode

**Add additional information for testing, if required**

## Screenshots:

**Add screenshots, if they are helpful**
