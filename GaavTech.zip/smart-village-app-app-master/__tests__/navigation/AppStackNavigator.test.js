import AppStackNavigator from '../../src/navigation/AppStackNavigator';

describe('AppStackNavigator', () => {
  it('creates correctly', () => {
    expect(AppStackNavigator).toMatchSnapshot();
  });
});
