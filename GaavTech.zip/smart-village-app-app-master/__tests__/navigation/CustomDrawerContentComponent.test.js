import { CustomDrawerContentComponent } from '../../src/navigation/CustomDrawerContentComponent';

describe('CustomDrawerContentComponent', () => {
  it('creates correctly', () => {
    expect(CustomDrawerContentComponent).toMatchSnapshot();
  });
});
