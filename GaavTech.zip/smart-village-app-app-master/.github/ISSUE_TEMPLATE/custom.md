---
name: Custom issue template
about: Tell us something related to the project
title: ''
labels: question
assignees: donni106

---

**Are there certain things to report that are not a bug or feature?**
Please tell us as exactly as possible about your request, thanks.
We will reply as soon as possible.
